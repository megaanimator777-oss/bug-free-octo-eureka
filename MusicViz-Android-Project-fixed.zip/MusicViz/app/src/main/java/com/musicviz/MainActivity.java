package com.musicviz;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.media.MediaPlayer;
import android.media.audiofx.BassBoost;
import android.media.audiofx.Visualizer;
import android.media.audiofx.Equalizer;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Canvas;
import android.view.View;
import android.view.Gravity;
import android.widget.*;
import android.database.Cursor;
import android.provider.OpenableColumns;
import java.util.ArrayList;
import java.io.*;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView trackInfo, status;
    private VisualizerView visualizerView;
    private MediaPlayer player;
    private Visualizer visualizer;
    private BassBoost bassBoost;
    private Equalizer equalizer;
    private final ArrayList<File> tracks = new ArrayList<>();
    private int current = 0;
    private boolean bassEnabled = false;
    private static final int PICK_AUDIO = 10, PICK_VIZ = 11;
    private File musicDir, presetDir;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8,10,16));
        getWindow().setNavigationBarColor(Color.rgb(8,10,16));
        musicDir = new File(getFilesDir(), "music");
        presetDir = new File(getFilesDir(), "presets");
        musicDir.mkdirs(); presetDir.mkdirs();
        refreshLibrary();
        buildUi();
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, 30);
        }
    }

    private TextView label(String text, int size) {
        TextView t = new TextView(this); t.setText(text); t.setTextColor(Color.WHITE);
        t.setTextSize(size); t.setGravity(Gravity.CENTER); return t;
    }
    private Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(35,43,62)));
        return b;
    }
    private void buildUi() {
        root = new LinearLayout(this); root.setOrientation(1);
        root.setPadding(20,24,20,16); root.setBackgroundColor(Color.rgb(8,10,16));
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this); content.setOrientation(1);
        TextView title = label("MUSICVIZ", 27); title.setTypeface(null,1);
        content.addView(title, new LinearLayout.LayoutParams(-1,70));
        content.addView(label("Независимая музыкальная библиотека",14), new LinearLayout.LayoutParams(-1,35));
        visualizerView = new VisualizerView();
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1,300);
        vp.setMargins(0,18,0,18); content.addView(visualizerView,vp);
        trackInfo = label("Добавь музыку в MusicViz",17);
        content.addView(trackInfo,new LinearLayout.LayoutParams(-1,55));
        status = label("Локальная библиотека готова",12);
        content.addView(status,new LinearLayout.LayoutParams(-1,30));

        Button add = button("＋ Импортировать музыку в MusicViz");
        add.setOnClickListener(v -> pick("audio/*",PICK_AUDIO));
        content.addView(add);
        Button library = button("♫ Моя библиотека");
        library.setOnClickListener(v -> showLibrary());
        content.addView(library);

        LinearLayout controls = new LinearLayout(this); controls.setGravity(Gravity.CENTER);
        Button prev = button("⏮"); Button play = button("▶ / ❚❚"); Button next = button("⏭");
        controls.addView(prev,new LinearLayout.LayoutParams(0,58,1));
        controls.addView(play,new LinearLayout.LayoutParams(0,58,1));
        controls.addView(next,new LinearLayout.LayoutParams(0,58,1));
        content.addView(controls);
        prev.setOnClickListener(v -> changeTrack(-1));
        next.setOnClickListener(v -> changeTrack(1));
        play.setOnClickListener(v -> togglePlayback());

        Button bass = button("♬ Усиление баса: ВЫКЛ");
        bass.setOnClickListener(v -> {
            bassEnabled = !bassEnabled; bass.setText("♬ Усиление баса: " + (bassEnabled?"ВКЛ":"ВЫКЛ"));
            applyBass();
        }); content.addView(bass);

        Button yandex = button("Открыть Яндекс Музыку");
        yandex.setOnClickListener(v -> openYandex()); content.addView(yandex);
        Button importViz = button("Импортировать пресет Avee (.viz)");
        importViz.setOnClickListener(v -> pick("*/*",PICK_VIZ)); content.addView(importViz);
        Button presets = button("Мои визуализации");
        presets.setOnClickListener(v -> showPresets()); content.addView(presets);

        TextView note = label("Важно: MusicViz копирует импортированные аудиофайлы в собственное хранилище. Удаление оригинала или изменение плейлиста в Яндекс Музыке не удалит эту копию. Защищённые загрузки Яндекс Музыки напрямую импортировать нельзя.",11);
        note.setTextColor(Color.LTGRAY); note.setPadding(4,14,4,12); content.addView(note);
        scroll.addView(content); root.addView(scroll); setContentView(root);
    }

    private void pick(String type,int request) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType(type);
        i.addCategory(Intent.CATEGORY_OPENABLE); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, request==PICK_AUDIO);
        startActivityForResult(i,request);
    }
    @Override protected void onActivityResult(int req,int res,Intent data) {
        super.onActivityResult(req,res,data);
        if(res!=RESULT_OK || data==null) return;
        if(req==PICK_AUDIO) {
            int imported=0;
            if(data.getClipData()!=null) {
                for(int i=0;i<data.getClipData().getItemCount();i++) {
                    if(copyIntoLibrary(data.getClipData().getItemAt(i).getUri())) imported++;
                }
            } else if(data.getData()!=null && copyIntoLibrary(data.getData())) imported++;
            refreshLibrary();
            status.setText("Импортировано файлов: "+imported);
            if(!tracks.isEmpty()) playTrack(Math.max(0,tracks.size()-imported));
        } else if(req==PICK_VIZ && data.getData()!=null) savePreset(data.getData());
    }

    // Copy bytes into app-private storage. The app no longer depends on the source URI.
    private boolean copyIntoLibrary(Uri uri) {
        String name = getName(uri);
        name = name.replaceAll("[^a-zA-Z0-9._() -]", "_");
        if(name.trim().isEmpty()) name = "audio_" + System.currentTimeMillis();
        int dot=name.lastIndexOf('.');
        String stem=dot>0?name.substring(0,dot):name;
        String ext=dot>0?name.substring(dot):".audio";
        File target=new File(musicDir,name);
        int n=1;
        while(target.exists()) target=new File(musicDir,stem+"_"+(n++)+ext);
        try(InputStream in=getContentResolver().openInputStream(uri);
            OutputStream out=new BufferedOutputStream(new FileOutputStream(target))) {
            if(in==null) return false;
            byte[] buf=new byte[16384]; int count;
            while((count=in.read(buf))!=-1) out.write(buf,0,count);
            out.flush();
            return target.length()>0;
        } catch(Exception e) {
            if(target.exists()) target.delete();
            status.setText("Ошибка импорта: "+e.getMessage());
            return false;
        }
    }
    private void refreshLibrary() {
        tracks.clear();
        File[] files=musicDir==null?null:musicDir.listFiles();
        if(files!=null) {
            for(File f:files) if(f.isFile() && f.length()>0) tracks.add(f);
        }
        java.util.Collections.sort(tracks,(a,b)->a.getName().compareToIgnoreCase(b.getName()));
    }
    private String getName(Uri uri) {
        String name="audio_"+System.currentTimeMillis();
        try(Cursor c=getContentResolver().query(uri,null,null,null,null)) {
            if(c!=null && c.moveToFirst()) {
                int ix=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if(ix>=0 && c.getString(ix)!=null) name=c.getString(ix);
            }
        } catch(Exception ignored) {}
        return name;
    }
    private void showLibrary() {
        refreshLibrary();
        if(tracks.isEmpty()) {
            new android.app.AlertDialog.Builder(this).setTitle("Моя библиотека")
                .setMessage("Пока нет сохранённых треков. Нажми «Импортировать музыку в MusicViz».")
                .setPositiveButton("ОК",null).show();
            return;
        }
        String[] names=new String[tracks.size()];
        for(int i=0;i<tracks.size();i++) names[i]=(i+1)+". "+tracks.get(i).getName();
        new android.app.AlertDialog.Builder(this).setTitle("Моя музыка — "+tracks.size()+" треков")
            .setItems(names,(d,which)-> {
                current=which; playTrack(which);
                new android.app.AlertDialog.Builder(this).setTitle(tracks.get(which).getName())
                    .setMessage("Файл хранится внутри MusicViz и не зависит от исходного файла или плейлиста.")
                    .setPositiveButton("Слушать", (dd,w)->playTrack(which))
                    .setNegativeButton("Удалить из MusicViz",(dd,w)-> {
                        if(player!=null && current==which) releasePlayer();
                        tracks.get(which).delete(); refreshLibrary();
                        status.setText("Файл удалён из библиотеки MusicViz");
                    }).setNeutralButton("Отмена",null).show();
            }).setNegativeButton("Закрыть",null).show();
    }
    private void playTrack(int index) {
        refreshLibrary();
        if(tracks.isEmpty()) { status.setText("Библиотека пуста"); return; }
        current=(index+tracks.size())%tracks.size();
        releasePlayer();
        try {
            player=new MediaPlayer(); player.setDataSource(tracks.get(current).getAbsolutePath());
            player.setOnPreparedListener(mp -> {
                mp.start(); trackInfo.setText(tracks.get(current).getName());
                status.setText("Играет из локальной копии • "+(current+1)+" из "+tracks.size());
                attachEffects();
            });
            player.setOnCompletionListener(mp -> changeTrack(1));
            player.prepareAsync();
        } catch(Exception e) { status.setText("Не удалось открыть аудио: "+e.getMessage()); }
    }
    private void togglePlayback() {
        if(player==null) { refreshLibrary(); if(!tracks.isEmpty()) playTrack(current); else pick("audio/*",PICK_AUDIO); }
        else if(player.isPlaying()) { player.pause(); status.setText("Пауза"); }
        else { player.start(); status.setText("Играет из MusicViz"); }
    }
    private void changeTrack(int d) { refreshLibrary(); if(!tracks.isEmpty()) playTrack(current+d); }
    private void attachEffects() {
        try {
            int id=player.getAudioSessionId();
            visualizer=new Visualizer(id); visualizer.setCaptureSize(Visualizer.getCaptureSizeRange()[1]);
            visualizer.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
                public void onWaveFormDataCapture(Visualizer v,byte[] data,int rate) { visualizerView.setWave(data); }
                public void onFftDataCapture(Visualizer v,byte[] data,int rate) { visualizerView.setFft(data); }
            },Visualizer.getMaxCaptureRate()/2,true,true);
            visualizer.setEnabled(true); applyBass();
        } catch(Exception e) { status.setText("Визуализатор недоступен на этом устройстве"); }
    }
    private void applyBass() {
        try {
            if(player==null) return;
            int id=player.getAudioSessionId();
            if(bassBoost!=null) bassBoost.release();
            bassBoost=new BassBoost(0,id); bassBoost.setEnabled(bassEnabled);
            if(bassEnabled) bassBoost.setStrength((short)850);
            if(equalizer!=null) equalizer.release();
            equalizer=new Equalizer(0,id); equalizer.setEnabled(bassEnabled);
            if(bassEnabled && equalizer.getNumberOfBands()>0) {
                short band=(short)(equalizer.getNumberOfBands()-1);
                short[] range=equalizer.getBandLevelRange();
                equalizer.setBandLevel(band,range[1]);
            }
        } catch(Exception ignored) {}
    }
    private void releasePlayer() {
        try { if(visualizer!=null) { visualizer.setEnabled(false); visualizer.release(); } } catch(Exception ignored) {}
        visualizer=null;
        try { if(bassBoost!=null) bassBoost.release(); } catch(Exception ignored) {}
        try { if(equalizer!=null) equalizer.release(); } catch(Exception ignored) {}
        bassBoost=null; equalizer=null;
        if(player!=null) { try { player.stop(); } catch(Exception ignored) {} player.release(); player=null; }
    }
    private void openYandex() {
        Intent i=getPackageManager().getLaunchIntentForPackage("ru.yandex.music");
        if(i==null) i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://music.yandex.ru/"));
        try { startActivity(i); status.setText("Яндекс Музыка открыта отдельно — MusicViz работает независимо"); }
        catch(Exception e) { status.setText("Не удалось открыть Яндекс Музыку"); }
    }
    private void savePreset(Uri uri) {
        try {
            String name="preset_"+System.currentTimeMillis()+".viz";
            try(InputStream in=getContentResolver().openInputStream(uri);
                FileOutputStream os=new FileOutputStream(new File(presetDir,name))) {
                byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0) os.write(buf,0,n);
            }
            status.setText("Пресет .viz сохранён. Рендерер Avee пока не реализован.");
        } catch(Exception e) { status.setText("Ошибка импорта пресета"); }
    }
    private void showPresets() {
        File[] list=presetDir.listFiles();
        StringBuilder b=new StringBuilder("Импортированные .viz:\n");
        if(list==null || list.length==0) b.append("Пока нет файлов");
        else for(File f:list) b.append("• ").append(f.getName()).append("\n");
        new android.app.AlertDialog.Builder(this).setTitle("Мои визуализации").setMessage(b.toString()).setPositiveButton("ОК",null).show();
    }
    @Override protected void onDestroy() { releasePlayer(); super.onDestroy(); }

    class VisualizerView extends View {
        private byte[] fft=new byte[0], wave=new byte[0];
        private final Paint p=new Paint(3);
        public VisualizerView() { super(MainActivity.this); setBackgroundColor(Color.rgb(13,17,28)); }
        void setFft(byte[] b) { fft=b.clone(); postInvalidate(); }
        void setWave(byte[] b) { wave=b.clone(); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c); float w=getWidth(), h=getHeight();
            p.setColor(Color.rgb(22,30,48)); p.setStrokeWidth(1);
            for(int y=1;y<5;y++) c.drawLine(0,h*y/5,w,h*y/5,p);
            int count=Math.max(1,Math.min(fft.length/2,90)); float bar=w/count;
            for(int i=0;i<count;i++) {
                int raw=fft.length>i*2+1 ? (fft[i*2+1]&255) : 0;
                float value=(float)Math.pow(raw/255f,1.4)*h*.82f;
                p.setColor(Color.rgb(0,190+(i%60),255));
                c.drawRoundRect(i*bar+2,h-value,Math.max(i*bar+3,(i+1)*bar-2),h-5,bar/3,bar/3,p);
            }
            if(fft.length==0) {
                p.setColor(Color.rgb(0,190,255)); p.setTextSize(17); p.setTextAlign(Paint.Align.CENTER);
                c.drawText("MUSIC VISUALIZER",w/2,h/2,p);
                p.setTextSize(11); c.drawText("Добавь трек, чтобы начать",w/2,h/2+25,p);
            }
        }
    }
}
